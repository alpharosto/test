# opp_proj
pip install language_tool_python
pip install autocorrect
pip install pylance
import re is use for regular expression operation use to A regular expression (or RE) specifies a set of strings that matches it; the functions in this module let you check if a particular string matches a given regular expression (or if a given regular expression matches a particular string, which comes down to the same thing).
